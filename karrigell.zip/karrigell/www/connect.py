from datetime import date, timedelta
template=Import('template.py')

def index():
    result=template.entete()
    result+=template.nav()
    result+='''
           <form method="post" action="checklogin" class="log">
                <fieldset>
                    <legend>Connexion</legend>
                    <p>
                    <label for="login">Login :</label><input name="login" type="text" id="login" /><br />
                    <label for="password">Mot de Passe :</label><input type="password" name="password" id="password" />
                    </p>
                </fieldset>
                <p><button class="button" type="submit">Se connecter</button></p></form>
    '''

    if "nom" in Session() and Session()["nom"]!='':
        result+=Session()["nom"]
        result+=Session()["pwd"]
        del Session()["nom"]
        del Session()["pwd"]

        if  "compteur" in COOKIE :
            newcookie=int(COOKIE["compteur"].value)+1
            SET_COOKIE["compteur"]=newcookie
            SET_COOKIE["compteur"]['path'] = '/'

            result+="<br />Vous vous êtes connecté "+COOKIE["compteur"].value+" fois"

            if int(COOKIE["compteur"].value)==5:
                eraseCookie("compteur")

        else:
            SET_COOKIE["compteur"]=1
            SET_COOKIE["compteur"]['path'] = '/'
            exp = date.today() + timedelta(days = 14) # 14 jours à partir de maintenant
            exp=exp.strftime("%a, %d-%b-%Y 12:55:48 GMT")   #'Sat, 28-feb-2015 12:55:48 GMT'
            SET_COOKIE["compteur"]['expires'] = exp



    else:
        result+="pas de session"



    result+="</body></html>"
    return result

def eraseCookie(name):
    SET_COOKIE[name] = ''
    SET_COOKIE[name]['path'] = '/'

    exp = date.today() + timedelta(days = -10) # 10 jours avant maintenant
    exp=exp.strftime("%a, %d-%b-%Y 12:55:48 GMT")
    SET_COOKIE[name]['expires'] = exp

    SET_COOKIE[name]['max-age'] = 0

    if name in COOKIE:  del(COOKIE[name])



def checklogin(login='', password=''):
    Session()["nom"]=login
    Session()["pwd"]=password
    raise HTTP_REDIRECTION('index')


