HTMLTags : HTML tag generation in Python scripts
Used in the web framework Karrigell
Home : http://code.google.com/p/karrigell/
Google Group : http://groups.google.com/group/karrigell