data = B('foobar')

def _(txt):
    return I(txt)