import Karrigell

Karrigell.run()
