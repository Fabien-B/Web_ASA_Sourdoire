def index(data1):
    out = open(THIS.abs_path('image.jpg'),'wb')
    nb_chunks = 0
    while True:
        buf = data1.file.read()
        if not buf:
            break
        nb_chunks += 1
        out.write(buf)
    return "ok",nb_chunks,"chunks"