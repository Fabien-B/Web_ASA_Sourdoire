﻿# -*- coding: utf-8  -*-


def index():

    return "नई दिल्ली।। बुलावे"